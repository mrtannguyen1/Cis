package com.example.weightapp

import android.icu.text.SimpleDateFormat
import androidx.lifecycle.ViewModel
import java.util.Date
import java.util.Calendar
import java.util.Locale
import android.net.Uri
import android.view.View
import androidx.navigation.NavDirections
import androidx.navigation.Navigation

class SharedViewModel : ViewModel() {
    var entryImageFilePath: String = ""
    var goalWeightLabel: String = "lbs"
    var preEntryUnit: String = "lbs"
    var settingHeightLabel: String = "ft in"
    var entryCurrentWeight: Double = 150.0
    var entryCurrentDate: Date? = null
    var historyCurrentWeight: Double = 150.0
    var settingHightvalue: String = "5'10\""
    var settingBeginWeight: String = "150"
    var summaryHeightValue: String = "170 cm"
    var summaryWeightValue: String = "150 lbs"

    // Change from MutableLiveData to List
    var historyList: List<HistoryEntity> = emptyList()
        set(value) {
            field = value}

    // Update the historyList directly without using MutableLiveData
    fun updateHistoryList(newList: List<HistoryEntity>) {
        historyList = newList.sortedByDescending { it.date }
    }

    var weeklyAverageWeightLoss: Double = 0.0

    fun calculateWeeklyAverageWeightLoss() {
        val weeksMap = mutableMapOf<String, MutableList<Double>>()

        // Group weights by week
        for (historyItem in historyList) {
            val weekKey = getWeekKey(historyItem.date)
            weeksMap.computeIfAbsent(weekKey) { mutableListOf() }.add(historyItem.weight.toDouble())
        }

        val weeklyAverages = mutableListOf<Double>()

        for (weekKey in weeksMap.keys) {
            val weekWeights = weeksMap[weekKey] ?: continue

            if (weekWeights.size > 1) {
                val newestWeight = weekWeights.maxOrNull() ?: 0.0
                val oldestWeight = weekWeights.minOrNull() ?: 0.0
                val weeklyAverage = (oldestWeight - newestWeight) / weekWeights.size
                weeklyAverages.add(weeklyAverage)
            }
        }

        val overallWeeklyAverage = weeklyAverages.average()
        weeklyAverageWeightLoss = overallWeeklyAverage
    }

    private fun getWeekKey(date: String): String {
        try {
            val dateFormat = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
            val parsedDate = dateFormat.parse(date)

            val calendar = Calendar.getInstance()
            calendar.time = parsedDate ?: Date()

            val weekInYear = calendar[Calendar.WEEK_OF_YEAR]
            return weekInYear.toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return ""
    }
    fun closeFullScreen(view: View) {
        val navController = Navigation.findNavController(view)
        navController.popBackStack()
    }
}
