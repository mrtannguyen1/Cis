package com.example.weightapp

import com.google.gson.annotations.SerializedName
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.weightapp.databinding.FragmentSettingBinding
import androidx.lifecycle.ViewModelProvider
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.io.FileReader
import java.io.FileWriter

class Setting : Fragment() {
    data class Settings(
        @SerializedName("weight") val weight: String,
        @SerializedName("height") val height: String,
        @SerializedName("goal_weight") val goalWeight: String,
        @SerializedName("target_date") val targetDate: String,
        @SerializedName("username") val username: String,
        @SerializedName("checkbox_lbs") val checkboxLbs: Boolean,
        @SerializedName("checkbox_kgs") val checkboxKgs: Boolean,
        @SerializedName("checkbox_fitin") val checkboxFitIn: Boolean,
        @SerializedName("checkbox_cm") val checkboxCm: Boolean,
        @SerializedName("checkbox_male") val checkboxMale: Boolean,
        @SerializedName("checkbox_female") val checkboxFemale: Boolean
    )
    private lateinit var binding: FragmentSettingBinding
    private lateinit var sharedPreferences: SharedPreferences

    // Default values
    private val defaultWeight = "150"
    private val defaultHeight = "5'10\""
    private val defaultGoalWeight = "130"
    private val defaultTargetDate = "01/01/2023"
    private val defaultUsername = "User Name"

    // Default checkbox states
    private val defaultCheckboxLbs = true
    private val defaultCheckboxKgs = false
    private val defaultCheckboxFtIn = true
    private val defaultCheckboxCm = false
    private val defaultCheckboxMale = true
    private val defaultCheckboxFemale = false

    // Current values (updated when the fragment is created)
    private var currentWeight: String = ""
    private var currentHeight: String = ""
    private var currentGoalWeight: String = ""
    private var currentTargetDate: String = ""
    private var currentUsername: String = ""
    private var currentCheckboxLbs: Boolean = true
    private var currentCheckboxKgs: Boolean = false
    private var currentCheckboxFitIn: Boolean = true
    private var currentCheckboxCm: Boolean = false
    private var currentCheckboxMale: Boolean = true
    private var currentCheckboxFemale: Boolean = false

    // Saved checkbox states
    private var savedWeight: String = ""
    private var savedHeight: String = ""
    private var savedGoalWeight: String = ""
    private var savedTargetDate: String = ""
    private var savedUsername: String = ""
    private var savedCheckboxLbs: Boolean = true
    private var savedCheckboxKgs: Boolean = false
    private var savedCheckboxFitIn: Boolean = true
    private var savedCheckboxCm: Boolean = false
    private var savedCheckboxMale: Boolean = true
    private var savedCheckboxFemale: Boolean = false


    private val settingsFileName = "settings.json"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentSettingBinding.inflate(inflater, container, false)
        return binding.root
    }

    private lateinit var sharedViewModel: SharedViewModel

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //loadSettingsFromFile()
        sharedViewModel = ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)

        sharedPreferences =
            requireActivity().getSharedPreferences("WeightAppPrefs", Context.MODE_PRIVATE)

        // Load saved values
        currentWeight = sharedPreferences.getString("weight", defaultWeight) ?: defaultWeight
        currentHeight = sharedPreferences.getString("height", defaultHeight) ?: defaultHeight
        currentGoalWeight =
            sharedPreferences.getString("goal_weight", defaultGoalWeight) ?: defaultGoalWeight
        currentTargetDate =
            sharedPreferences.getString("target_date", defaultTargetDate) ?: defaultTargetDate
        currentUsername =
            sharedPreferences.getString("username", defaultUsername) ?: defaultUsername
        currentCheckboxLbs = sharedPreferences.getBoolean("checkbox_lbs", defaultCheckboxLbs)
        currentCheckboxKgs = sharedPreferences.getBoolean("checkbox_kgs", defaultCheckboxKgs)
        currentCheckboxFitIn =
            sharedPreferences.getBoolean("checkbox_fitin", defaultCheckboxFtIn)
        currentCheckboxCm = sharedPreferences.getBoolean("checkbox_cm", defaultCheckboxCm)
        currentCheckboxMale = sharedPreferences.getBoolean("checkbox_male", defaultCheckboxMale)
        currentCheckboxFemale =
            sharedPreferences.getBoolean("checkbox_female", defaultCheckboxFemale)

        binding.weightInput.setText(currentWeight)
        binding.heightInput.setText(currentHeight)
        binding.goalWeightInput.setText(currentGoalWeight)
        binding.targetDateInput.setText(currentTargetDate)
        binding.usernameInput.setText(currentUsername)

        // Set checkbox states
        binding.checkboxlbs.isChecked = currentCheckboxLbs
        binding.checkboxkgs.isChecked = currentCheckboxKgs
        binding.checkboxftin.isChecked = currentCheckboxFitIn
        binding.checkboxcm.isChecked = currentCheckboxCm
        binding.checkboxmale.isChecked = currentCheckboxMale
        binding.checkboxfemale.isChecked = currentCheckboxFemale
        savedCheckboxLbs = currentCheckboxLbs
        savedCheckboxKgs = currentCheckboxKgs
        savedCheckboxFitIn = currentCheckboxFitIn
        savedCheckboxCm = currentCheckboxCm
        savedCheckboxMale = currentCheckboxMale
        savedCheckboxFemale = currentCheckboxFemale

        // Set initial goal weight label and input based on the current unit
        updateGoalWeightLabelAndInput()
        sharedViewModel.preEntryUnit = binding.goalweightlable.text.toString()

        // Save Button Click Listener
        binding.settingSave.setOnClickListener {
            saveValues()
            saveSettingsToFile()
        }

        // Cancel Button Click Listener
        binding.settingCancel.setOnClickListener {
            resetToSavedValues()
            // Close the fragment after resetting
        }

        // Checkbox listeners
        binding.checkboxlbs.setOnCheckedChangeListener { _, isChecked ->
            currentCheckboxLbs = isChecked
            if (isChecked) {
                binding.checkboxkgs.isChecked = false
                if (currentCheckboxLbs) {
                    convertKgsToLbs()
                }
            }
            updateGoalWeightLabelAndInput()
        }

        binding.checkboxkgs.setOnCheckedChangeListener { _, isChecked ->
            currentCheckboxKgs = isChecked
            if (isChecked) {
                binding.checkboxlbs.isChecked = false
                // Convert from lbs to kgs if checkboxkgs is checked
                if (!currentCheckboxLbs) {
                    convertLbsToKgs()
                }
            }
            updateGoalWeightLabelAndInput()
        }

        binding.checkboxftin.setOnCheckedChangeListener { _, isChecked ->
            currentCheckboxFitIn = isChecked
            if (isChecked) {
                binding.checkboxcm.isChecked = false
                // Convert from cm to ft inches if checkboxftin is checked
                if (!currentCheckboxCm) {
                    convertCmToFtIn()
                }
            }
        }

        binding.checkboxcm.setOnCheckedChangeListener { _, isChecked ->
            currentCheckboxCm = isChecked
            if (isChecked) {
                binding.checkboxftin.isChecked = false
                // Convert from ft inches to cm if checkboxcm is checked
                if (!currentCheckboxFitIn) {
                    convertFtInToCm()
                }
            }
        }

        binding.checkboxmale.setOnCheckedChangeListener { _, isChecked ->
            currentCheckboxMale = isChecked
            if (isChecked) {
                binding.checkboxfemale.isChecked = false
            }
        }

        binding.checkboxfemale.setOnCheckedChangeListener { _, isChecked ->
            currentCheckboxFemale = isChecked
            if (isChecked) {
                binding.checkboxmale.isChecked = false
            }
        }
    }

    private fun saveValues() {

        currentUsername = binding.usernameInput.text.toString()
        currentGoalWeight = binding.goalWeightInput.text.toString()
        currentTargetDate = binding.targetDateInput.text.toString()
        sharedViewModel.settingBeginWeight=binding.weightInput.text.toString()
        with(sharedPreferences.edit()) {
            putString("weight", currentWeight)
            putString("height", currentHeight)
            putString("goal_weight", currentGoalWeight)
            putString("target_date", currentTargetDate)
            putString("username", currentUsername)
            putBoolean("checkbox_lbs", currentCheckboxLbs)
            putBoolean("checkbox_kgs", currentCheckboxKgs)
            putBoolean("checkbox_fitin", currentCheckboxFitIn)
            putBoolean("checkbox_cm", currentCheckboxCm)
            putBoolean("checkbox_male", currentCheckboxMale)
            putBoolean("checkbox_female", currentCheckboxFemale)
            apply()



            savedWeight = currentWeight
            savedHeight = currentHeight
            savedGoalWeight = currentGoalWeight
            Log.d("SaveSettings", currentGoalWeight)
            savedTargetDate = currentTargetDate
            savedUsername = currentUsername
            savedCheckboxLbs = currentCheckboxLbs
            savedCheckboxKgs = currentCheckboxKgs
            savedCheckboxFitIn = currentCheckboxFitIn
            savedCheckboxCm = currentCheckboxCm
            savedCheckboxMale = currentCheckboxMale
            savedCheckboxFemale = currentCheckboxFemale
            sharedViewModel.goalWeightLabel = binding.goalweightlable.text.toString()
            Log.d("SaveSettings", currentGoalWeight)
            sharedViewModel.settingHightvalue = binding.heightInput.text.toString()
        }
        fragmentManager?.popBackStack()
    }

    private fun resetToSavedValues() {
        // Reset input fields to previously saved values
        binding.weightInput.setText(savedWeight)
        binding.heightInput.setText(savedHeight)
        binding.goalWeightInput.setText(savedGoalWeight)
        binding.targetDateInput.setText(savedTargetDate)
        binding.usernameInput.setText(savedUsername)

        // Reset checkbox states to previously saved values
        binding.checkboxlbs.isChecked = savedCheckboxLbs
        binding.checkboxkgs.isChecked = savedCheckboxKgs
        binding.checkboxftin.isChecked = savedCheckboxFitIn
        binding.checkboxcm.isChecked = savedCheckboxCm
        binding.checkboxmale.isChecked = savedCheckboxMale
        binding.checkboxfemale.isChecked = savedCheckboxFemale
    }

    private fun convertLbsToKgs() {
        // Convert lbs to kgs and update currentWeight
        try {
            val lbs = currentWeight.toDouble()
            val kgs = lbs * 0.453592
            currentWeight = String.format("%.2f", kgs)
            binding.weightInput.setText(currentWeight)
            val goalWeight = binding.goalWeightInput.text.toString().toDouble()
            val convertedGoalWeight = goalWeight * 0.453592
            binding.goalWeightInput.setText(String.format("%.3f", convertedGoalWeight))
            currentGoalWeight = (String.format("%d", convertedGoalWeight.toInt()))
        } catch (e: NumberFormatException) {
            // Handle invalid input
        }
    }

    private fun convertKgsToLbs() {
        // Convert kgs to lbs and update currentWeight
        try {
            val kgs = currentWeight.toDouble()
            val lbs = kgs / 0.453592
            currentWeight = String.format("%d", lbs.toInt())
            binding.weightInput.setText(currentWeight)
            val goalWeight = binding.goalWeightInput.text.toString().toDouble()
            val convertedGoalWeight = goalWeight / 0.453592
            binding.goalWeightInput.setText(String.format("%d", convertedGoalWeight.toInt()))
            currentGoalWeight = (String.format("%d", convertedGoalWeight.toInt()))
        } catch (e: NumberFormatException) {
            // Handle invalid input
        }
    }

    private fun convertFtInToCm() {
        // Convert ft inches to cm and update currentHeight
        try {
            val ftInArray = currentHeight.split("'")
            val feet = ftInArray[0].toDouble()
            val inches = ftInArray[1].replace("\"", "").toDouble()
            val cm = (feet * 30.48) + (inches * 2.54)
            currentHeight = String.format("%.2f", cm)
            binding.heightInput.setText(currentHeight)
            sharedViewModel.settingHeightLabel = "cm"
        } catch (e: NumberFormatException) {
            // Handle invalid input
        }
    }

    private fun convertCmToFtIn() {
        // Convert cm to ft inches and update currentHeight
        try {
            val cm = currentHeight.toDouble()
            val feet = cm / 30.48
            val inches = (cm % 30.48) / 2.54
            currentHeight = "${feet.toInt()}'${String.format("%.0f", inches)}\""
            binding.heightInput.setText(currentHeight)
            sharedViewModel.settingHeightLabel = "ft in"
        } catch (e: NumberFormatException) {
            // Handle invalid input
        }
    }

    private fun updateGoalWeightLabelAndInput() {
        val goalWeightLabel = if (currentCheckboxLbs) {
            binding.goalweightlable.text = "lbs"
        } else {
            binding.goalweightlable.text = "kgs"
        }
        val savedHightLable = if (currentCheckboxFitIn) {
            sharedViewModel.settingHeightLabel = "ft in"

        } else {
            binding.goalweightlable.text = "kgs"
        }
        val savedHeightLabel = if (currentCheckboxFitIn) {
            sharedViewModel.settingHeightLabel = "ft in"
        } else {
            sharedViewModel.settingHeightLabel = "cm"
        }
    }

    private fun saveSettingsToFile() {
        val settings = Settings(
            currentWeight,
            currentHeight,
            currentGoalWeight,
            currentTargetDate,
            currentUsername,
            currentCheckboxLbs,
            currentCheckboxKgs,
            currentCheckboxFitIn,
            currentCheckboxCm,
            currentCheckboxMale,
            currentCheckboxFemale
        )

        val gson = Gson()
        val json = gson.toJson(settings)

        try {
            val file = File(requireContext().filesDir, "settings.json")
            val writer = FileWriter(file)
            writer.write(json)
            Log.d("SaveSettings", settings.username)
            writer.close()



        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadSettingsFromFile() {
        try {
            val file = File(requireContext().filesDir, "settings.json")
            if (file.exists()) {
                val reader = FileReader(file)
                val gson = Gson()
                val settings: Settings = gson.fromJson(reader, object : TypeToken<Settings>() {}.type)

                // Update current values
                currentWeight = settings.weight
                currentHeight = settings.height
                currentGoalWeight = settings.goalWeight
                currentTargetDate = settings.targetDate
                currentUsername = settings.username
                currentCheckboxLbs = settings.checkboxLbs
                currentCheckboxKgs = settings.checkboxKgs
                currentCheckboxFitIn = settings.checkboxFitIn
                currentCheckboxCm = settings.checkboxCm
                currentCheckboxMale = settings.checkboxMale
                currentCheckboxFemale = settings.checkboxFemale

                // Update UI
                binding.weightInput.setText(currentWeight)
                binding.heightInput.setText(currentHeight)
                binding.goalWeightInput.setText(currentGoalWeight)
                binding.targetDateInput.setText(currentTargetDate)
                binding.usernameInput.setText(currentUsername)
                binding.checkboxlbs.isChecked = currentCheckboxLbs
                binding.checkboxkgs.isChecked = currentCheckboxKgs
                binding.checkboxftin.isChecked = currentCheckboxFitIn
                binding.checkboxcm.isChecked = currentCheckboxCm
                binding.checkboxmale.isChecked = currentCheckboxMale
                binding.checkboxfemale.isChecked = currentCheckboxFemale

                // Update goal weight label and input based on the current unit
                updateGoalWeightLabelAndInput()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

