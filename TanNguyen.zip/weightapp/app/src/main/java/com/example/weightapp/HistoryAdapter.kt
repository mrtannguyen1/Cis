// HistoryAdapter.kt
package com.example.weightapp

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.weightapp.databinding.ItemHistoryBinding

    class HistoryAdapter(
        private val onItemClick: (HistoryEntity) -> Unit,
    ) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    private var sortedList: MutableList<HistoryEntity> = mutableListOf()

    init {
        updateList(emptyList())
    }

    fun updateList(newList: List<HistoryEntity>) {
        sortedList = newList.toMutableList()
        sortedList.sortByDescending { it.date.split("/").reversed().joinToString("-") }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val historyItem = sortedList[position]
        holder.bind(historyItem)

        // Set a click listener for the entire row
        holder.itemView.setOnClickListener {
            onItemClick(historyItem)
        }

        // Check if it's not the last item
        if (position < itemCount - 1) {
            val nextWeight = sortedList[position + 1].weight
            val currentWeight = historyItem.weight

            // Calculate the weight difference with the next item
            val weightDifference = nextWeight.toDouble() - currentWeight.toDouble()

            // Set trend text and color based on weight difference
            when {
                weightDifference > 0 -> {
                    holder.binding.trendTextView.text = "Loss"
                    setTrendTextViewStyle(holder, R.color.green)
                }
                weightDifference < 0 -> {
                    holder.binding.trendTextView.text = "Gain"
                    setTrendTextViewStyle(holder, R.color.red)
                }
                else -> {
                    holder.binding.trendTextView.text = "Same"
                    setTrendTextViewStyle(holder, R.color.balance)
                }
            }
        }
    }

    private fun setTrendTextViewStyle(holder: ViewHolder, colorResId: Int) {
        holder.binding.trendTextView.setTextColor(
            ContextCompat.getColor(
                holder.itemView.context,
                R.color.white
            )
        )
        holder.binding.trendTextView.setBackgroundResource(colorResId)
    }

    override fun getItemCount(): Int {
        return sortedList.size
    }

    class ViewHolder(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(historyItem: HistoryEntity) {
            binding.dateTextView.text = historyItem.date
            binding.weightTextView.text = historyItem.weight

            // Assuming you have an ImageView in your layout with id 'imageView'
            val imageUri = historyItem.imageUri?.let { Uri.parse(it) }

            // Assuming you have an ImageView in your layout with id 'imageView'
            Glide.with(binding.historyImageView.context)
                .load(imageUri)
                .into(binding.historyImageView)
        }
    }
}
