package com.example.weightapp

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.OnConflictStrategy


// Inside HistoryDao.kt
@Dao
interface HistoryDao {
    @Insert
    suspend fun insertHistory(history: HistoryEntity)

    @Query("SELECT * FROM history_table ORDER BY date DESC")
    suspend fun getAllHistory(): List<HistoryEntity>

    @Query("DELETE FROM history_table WHERE id = :historyId")
    suspend fun deleteHistoryById(historyId: Long)

    @Query("UPDATE history_table SET weight = :newWeight WHERE id = :historyId")
    suspend fun updateWeight(historyId: Long, newWeight: Double)
}





