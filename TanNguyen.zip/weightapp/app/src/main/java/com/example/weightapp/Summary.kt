package com.example.weightapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.weightapp.databinding.FragmentSummaryBinding
import android.util.Log

class Summary : Fragment() {

    // Other code...

    private lateinit var sharedViewModel: SharedViewModel
    private var _binding: FragmentSummaryBinding? = null
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSummaryBinding.inflate(inflater, container, false)
        val view = binding.root

        // Initialize shared ViewModel
        sharedViewModel = ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)

        // Observe changes in the settingHightvalue property


        return view
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.heightValue.text = "${sharedViewModel.settingHightvalue} ${sharedViewModel.settingHeightLabel}"
        binding.weightValue.text = "${sharedViewModel.historyCurrentWeight} ${sharedViewModel.goalWeightLabel}"
        binding.weeklyWeightLossValue.text = "${sharedViewModel.weeklyAverageWeightLoss}"
        var weightLossValue: Double = 0.0
        val beginWeight = sharedViewModel.settingBeginWeight.toDouble()
        val currentWeight = sharedViewModel.historyCurrentWeight

        weightLossValue = beginWeight - currentWeight
        binding.weightLossValue.text = "$weightLossValue"
        calculateAndSetBMI()
    }
    // Other code...

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun calculateAndSetBMI() {
        val weightInLbs: Double
        val heightInInches: Double

        // Convert weight to lbs if it's in kgs
        if (sharedViewModel.goalWeightLabel == "kgs") {
            weightInLbs = sharedViewModel.historyCurrentWeight / 0.453592
        } else {
            weightInLbs = sharedViewModel.historyCurrentWeight
        }

        // Convert height to inches, whether it's in ft in or cm
        heightInInches = when (sharedViewModel.settingHeightLabel) {
            "ft in" -> parseHeightToInches(sharedViewModel.settingHightvalue)
            "cm" -> sharedViewModel.settingHightvalue.toDouble() / 2.54
            else -> 0.0
        }

        if (heightInInches > 0) {
            // Calculate BMI using the standard formula
            val bmi = (weightInLbs / (heightInInches * heightInInches)) * 703
            binding.bmiValue.text = String.format("%.2f", bmi)

        }
    }

    private fun parseHeightToInches(height: String): Double {
        val feetAndInches = height.split("'")

        val feet = if (feetAndInches.isNotEmpty()) {
            feetAndInches[0].toDoubleOrNull() ?: 0.0
        } else {
            0.0
        }

        val inches = if (feetAndInches.size > 1) {
            val inchesPart = feetAndInches[1].substringBefore("\"").toDoubleOrNull() ?: 0.0
            inchesPart / 12.0
        } else {
            0.0
        }

        return (feet * 12) + inches
    }


}
