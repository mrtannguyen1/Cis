package com.example.weightapp

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.content.PermissionChecker
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.weightapp.databinding.FragmentEntryBinding
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.FileWriter
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.pow
import kotlin.math.roundToLong

class Entry : Fragment() {

    private lateinit var sharedViewModel: SharedViewModel
    private var _binding: FragmentEntryBinding? = null
    private val binding get() = _binding!!

    private val CAMERA_PERMISSION_REQUEST_CODE = 123
    private val takePictureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val imageUri = result.data?.extras?.get("data") as Bitmap
                val imagePath = saveImageToStorage(imageUri)
                // Here you can insert this imagePath into your room database.
                Log.d("Saved Image File", "Saved Image File: $imagePath")

                // Save the image URI to the history entry
                loadImageIntoImageView(saveImageToStorage(imageUri))

            }
        }

    private fun saveImageToStorage(bitmap: Bitmap): Uri? {
        val timeStamp =
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val imageFileName = "JPEG_$timeStamp.jpg"
        val storageDir: File? =
            requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)

        return try {
            val imageFile = File(storageDir, imageFileName)
            val fos = FileOutputStream(imageFile)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
            fos.close()

            // Convert the file path to a Uri
            FileProvider.getUriForFile(
                requireContext(),
                "com.example.weightapp.fileprovider",  // replace with your app's file provider authority
                imageFile
            )
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentEntryBinding.inflate(inflater, container, false)
        val view = binding.root

        // Initialize the shared ViewModel
        sharedViewModel =
            ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)
        sharedViewModel.calculateWeeklyAverageWeightLoss()
        // Get the current date and format it
        val dateFormat = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
        val currentDate = dateFormat.format(Date())
        binding.entryWeightInput.setText(sharedViewModel.entryCurrentWeight.toString())

        // Set the current date to the entryDateValue TextView
        binding.entryDateValue.text =
            getString(R.string.entry_date_label, currentDate)
        // Observe changes in the shared ViewModel and update the label accordingly
        binding.entryUnit.text =
            getString(R.string.entry_unit_lablel, sharedViewModel.goalWeightLabel)

        // Set up the DatePicker
        val datePicker = binding.datePicker
        val currentDateCal = Calendar.getInstance()
        binding.entryDateValue.text = dateFormat.format(currentDateCal.time)
        currentDateCal.time = sharedViewModel.entryCurrentDate ?: Date()
        datePicker.init(
            currentDateCal.get(Calendar.YEAR),
            currentDateCal.get(Calendar.MONTH),
            currentDateCal.get(Calendar.DAY_OF_MONTH)
        ) { _, year, monthOfYear, dayOfMonth ->
            val selectedDate = Calendar.getInstance()
            selectedDate.set(year, monthOfYear, dayOfMonth)

            // Check if the selected date is in the future
            if (selectedDate.after(Calendar.getInstance())) {
                // Display a Snackbar message
                Snackbar.make(
                    binding.root,
                    "Selected date is in the future. This will be considered a valid input.",
                    Snackbar.LENGTH_SHORT
                ).show()

                // Set the selected date to the entryDateValue TextView
                binding.entryDateValue.text = dateFormat.format(selectedDate.time)

                // Make the Save button invisible
                binding.entrySave.visibility = View.INVISIBLE
            } else {
                // Set the current date if it's not in the future
                binding.entryDateValue.text = dateFormat.format(selectedDate.time)

                // Make the Save button visible
                binding.entrySave.visibility = View.VISIBLE
            }
        }

        // Check and convert weight units if needed
        if (sharedViewModel.preEntryUnit != sharedViewModel.goalWeightLabel) {
            val currentWeight = sharedViewModel.entryCurrentWeight

            if (sharedViewModel.goalWeightLabel == "kgs") {
                // Convert to kgs
                sharedViewModel.entryCurrentWeight =
                    (currentWeight * 0.453592).roundTo(2)
                sharedViewModel.preEntryUnit = "kgs"
            } else {
                // Convert to lbs
                sharedViewModel.entryCurrentWeight =
                    (currentWeight / 0.453592).roundTo(0)
                sharedViewModel.preEntryUnit = "lbs"
            }
        }

        // Set click listeners for Save and Cancel buttons
        binding.entrySave.setOnClickListener {
            val currentDate = dateFormat.parse(binding.entryDateValue.text.toString())
            val currentWeight = binding.entryWeightInput.text.toString().toDouble()

            sharedViewModel.entryCurrentDate = currentDate
            sharedViewModel.entryCurrentWeight = currentWeight
            sharedViewModel.preEntryUnit = binding.entryUnit.text.toString()
            val builder = AlertDialog.Builder(requireContext())
            if (sharedViewModel.entryImageFilePath == "") {
                builder.setTitle("Warning")
                builder.setMessage("Picture is not taken yet. Please take a picture before saving.")
                builder.setPositiveButton("OK") { _, _ ->
                    // Handle the "OK" button click if needed
                }

                val dialog = builder.create()
                dialog.show()

            } else {
                val builder = AlertDialog.Builder(requireContext())
                builder.setTitle("Confirmation")
                builder.setMessage("Are you sure you want to save new entry?")
                builder.setPositiveButton("Yes") { _, _ ->
                    // User clicked "Yes," perform the update here
                    saveToHistory()
                    binding.entrySave.visibility = View.VISIBLE
                    sharedViewModel.entryImageFilePath = ""
                    binding.entryImageView.setImageResource(R.drawable.profile)
                                }
                builder.setNegativeButton("No") { _, _ ->
                    // User clicked "No," do nothing or handle accordingly
                }
                val dialog = builder.create()
                dialog.show()
                // If entryImageFilePath is not an empty string, make the entrySaveButton visible

            }

        }

        binding.entryCancel.setOnClickListener {
            resetToOriginalWeight()
        }
        binding.entryWeightInput.setText(sharedViewModel.entryCurrentWeight.toString())

        // Set click listener for the camera button
        binding.entryTakePicture.setOnClickListener {
            // Check if CAMERA permission is granted
            if (ContextCompat.checkSelfPermission(
                    requireContext(),
                    android.Manifest.permission.CAMERA
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // Request the CAMERA permission
                requestPermissions(
                    arrayOf(android.Manifest.permission.CAMERA),
                    CAMERA_PERMISSION_REQUEST_CODE
                )
            } else {
                // CAMERA permission is already granted, proceed with the camera action
                openCamera()
            }
        }

        return view
    }
    private fun saveToHistory() {
        val date = binding.entryDateValue.text.toString()
        val weight = binding.entryWeightInput.text.toString()
        val imageUri = sharedViewModel.entryImageFilePath

        // Creating a HistoryEntity with the provided data
        val historyEntity = HistoryEntity(
            date = date,
            weight = weight,
            imageUri = imageUri
        )

        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                val historyDao = HistoryDatabase.getDatabase(requireContext()).historyDao()
                historyDao.insertHistory(historyEntity)
                // Retrieve all history entries
                var allHistory = historyDao.getAllHistory().toMutableList()

                // Now, the database contains all the history entries sorted by date
                Log.d("All History", allHistory.toString())
            }
        }
    }



    // Add this function to handle the permission result
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Camera permission granted, proceed with the camera action
                openCamera()
            } else {
                // Camera permission denied, show a message or handle accordingly
                Snackbar.make(
                    binding.root,
                    "Camera permission is required to take pictures.",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun resetToOriginalWeight() {
        binding.entryWeightInput.setText(sharedViewModel.entryCurrentWeight.toString())
        binding.entryImageView.setImageResource(R.drawable.profile)
    }



    private fun openCamera() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        takePictureLauncher.launch(takePictureIntent)
    }

    private fun loadImageIntoImageView(imageUri: Uri?) {
        // Load the image into the ImageView using Glide
        Glide.with(this)
            .load(imageUri)
            .into(binding.entryImageView)
        val imagePath = imageUri?.path
        sharedViewModel.entryImageFilePath = imageUri.toString()

    }


    // Usage


    private fun Double.roundTo(decimalPlaces: Int): Double {
        val factor = 10.0.pow(decimalPlaces.toDouble())
        return (this * factor).roundToLong() / factor
    }
}
