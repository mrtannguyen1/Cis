    package com.example.weightapp

    import android.app.AlertDialog
    import android.net.Uri
    import android.os.Bundle
    import android.util.Log
    import android.view.LayoutInflater
    import android.view.View
    import android.view.ViewGroup
    import androidx.fragment.app.Fragment
    import androidx.lifecycle.ViewModelProvider
    import androidx.lifecycle.lifecycleScope
    import androidx.recyclerview.widget.LinearLayoutManager
    import com.bumptech.glide.Glide
    import com.example.weightapp.databinding.FragmentHistoryBinding
    import kotlinx.coroutines.Dispatchers
    import kotlinx.coroutines.launch
    import kotlinx.coroutines.runBlocking
    import kotlinx.coroutines.withContext

    class History : Fragment() {

        private var _binding: FragmentHistoryBinding? = null
        private val binding get() = _binding!!

        private lateinit var sharedViewModel: SharedViewModel
        private lateinit var historyAdapter: HistoryAdapter

        override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View {
            _binding = FragmentHistoryBinding.inflate(inflater, container, false)
            val view = binding.root

            sharedViewModel = ViewModelProvider(requireActivity()).get(SharedViewModel::class.java)

            // Pass a lambda to handle item clicks to the adapter
            historyAdapter = HistoryAdapter { historyItem ->
                openFullScreenImage(historyItem)
            }
            binding.WeightLossLabel.text = "${binding.WeightLossLabel.text.toString()} (${sharedViewModel.goalWeightLabel})"

            return view
        }




        override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
            super.onViewCreated(view, savedInstanceState)
            sharedViewModel.calculateWeeklyAverageWeightLoss()
            historyAdapter.updateList(loadHistoryFromDatabase())
        }

        override fun onDestroyView() {
            super.onDestroyView()
            _binding = null
        }

        // Utility function to load history from the database
        // Utility function to load history from the database
        private fun loadHistoryFromDatabase(): List<HistoryEntity> {
            binding.historyListRecyclerView.adapter = historyAdapter
            binding.historyListRecyclerView.layoutManager = LinearLayoutManager(requireContext())
            return runBlocking {
                return@runBlocking withContext(Dispatchers.IO) {
                    val historyDao = HistoryDatabase.getDatabase(requireContext()).historyDao()
                    val historyList = historyDao.getAllHistory()
                    // Update weights in the history_tabl
                    historyList.forEach { historyItem ->
                        val currentWeight = historyItem.weight.toDouble()
                        val newWeight = convertWeight(sharedViewModel.preEntryUnit.toString(), sharedViewModel.goalWeightLabel.toString(), currentWeight)
                        // Update the weight in the database
                        historyDao.updateWeight(historyItem.id, newWeight)
                    }
                    sharedViewModel.preEntryUnit = sharedViewModel.goalWeightLabel

                    val newestItem = historyDao.getAllHistory().maxByOrNull { it.date }
                    newestItem?.let {
                        sharedViewModel.historyCurrentWeight = it.weight.toDouble()
                    }
                    historyDao.getAllHistory()

                }

            }
            //Log.d("All new", historyList.toString())

        }

        private fun convertWeight(fromUnit: String, toUnit: String, weight: Double): Double {
            return when {
                fromUnit == "kgs" && toUnit == "lbs" -> String.format("%.2f", weight / 0.453592).toDouble()
                fromUnit == "lbs" && toUnit == "kgs" -> String.format("%.2f", weight * 0.453592).toDouble()
                else -> String.format("%.2f", weight).toDouble()


            }
        }

        // Utility function to set SharedViewModel.historyCurrentWeight to the weight of the newest date
        private fun setHistoryCurrentWeight() {

        }

        private fun openFullScreenImage(historyItem: HistoryEntity) {
            // Find the ImageView by its ID
            val fullScreenImage = _binding?.fullScreenImage
            val historyCloseButton = _binding?.historyClose
            val historyDeleteButton = _binding?.historyDelete

            // Set the visibility of the full-screen image to the opposite of its current visibility
            fullScreenImage?.let {

                it.visibility = if (it.visibility == View.VISIBLE) {
                    View.INVISIBLE
                } else {
                    // Load the full-size image using Glide when making it visible
                    Glide.with(this)
                        .load(Uri.parse(historyItem.imageUri))
                        .into(it)
                    historyCloseButton?.visibility = View.VISIBLE
                    historyDeleteButton?.visibility = View.VISIBLE
                    View.VISIBLE

                }
            }

            // Add a click listener to the full-screen image to toggle its visibility
            fullScreenImage?.setOnClickListener {
                fullScreenImage.visibility = View.INVISIBLE
                historyCloseButton?.visibility = View.INVISIBLE
                historyDeleteButton?.visibility = View.INVISIBLE
            }
            historyCloseButton?.setOnClickListener {
                fullScreenImage?.visibility = View.INVISIBLE
                historyCloseButton?.visibility = View.INVISIBLE
                historyDeleteButton?.visibility = View.INVISIBLE
            }
            historyDeleteButton?.setOnClickListener {
                val builder = AlertDialog.Builder(requireContext())
                builder.setTitle("Confirmation")
                builder.setMessage("Are you sure you want to delete this history item?")
                builder.setPositiveButton("Yes") { _, _ ->
                    // User clicked "Yes," perform the update here
                    val historyItemId = historyItem.id
                    // Delete the historyItem from the database
                    deleteHistoryItem(historyItemId)

                    fullScreenImage?.visibility = View.INVISIBLE
                    historyCloseButton?.visibility = View.INVISIBLE
                    historyDeleteButton?.visibility = View.INVISIBLE


                    historyAdapter.updateList(loadHistoryFromDatabase())                }
                builder.setNegativeButton("No") { _, _ ->
                    // User clicked "No," do nothing or handle accordingly
                }
                val dialog = builder.create()
                dialog.show()




            }

        }

        private fun deleteHistoryItem(historyItemId: Long) {
            // Run the database operation in a background thread
            runBlocking {
                withContext(Dispatchers.IO) {
                    val historyDao = HistoryDatabase.getDatabase(requireContext()).historyDao()
                    historyDao.deleteHistoryById(historyItemId)
                }
            }
        }

    }
